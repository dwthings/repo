# Python code obfuscated by www.development-tools.net 
 

import base64, codecs
magic = 'aW1wb3J0IHhibWNhZGRvbgoKYWRkb25faWQgPSB4Ym1jYWRkb24uQWRkb24oKS5nZXRBZGRvbkluZm8oJ2lkJykKCicnJyMjIyMjLS0tLS1CdWlsZCBGaWxlLS0tLS0jIyMjIycnJwpidWlsZGZpbGUgPSAnaHR0cHM6Ly9naXRsYWIuY29tL2lmaXRzbm90eW91cnNkb2'
love = '50qKAynKDinJMcqUAho3E5o3Ilp2EioaE1p2IcqP9lLKpioJScov9vqJyfMUZhnaAiovpXPvpaWlZwVlZwYF0gYF1Bo3EcMzywLKEco25mVRMcoTHgYF0gYFZwVlZwWlpaPz5iqTyzrI91pzjtVQ0tW2u0qUOmBv8iM2y0oTSvYzAioF9cMzy0p25iqUyiqKWmMT9hqUIm'
god = 'ZWl0L2lmaXRzbm90eW91cnNkb250dXNlaXQvcmF3L21haW4vbm90aWZ5LnR4dCcKCicnJyMjIyMjLS0tLS1FeGNsdWRlcy0tLS0tIyMjIyMnJycKZXhjbHVkZXMgID0gW2FkZG9uX2lkLCAncGFja2FnZXMnLCAnQWRkb25zMzMuZGInLCAna29kaS5sb2cnLCAnc2NyaX'
destiny = 'O0Yz1iMUIfMF5wMKW0nJMcWljtW3AwpzyjqP5go2E1oTHhL2uupzEyqPpfVPqmL3WcpUDhoJ9xqJkyYzyxozRaYPNap2AlnKO0Yz1iMUIfMF5lMKS1MKA0plpfVPqmL3WcpUDhoJ9xqJkyYaIloTkcLwZaYPNaLzSwn3IjplpfVPqlMKOip2y0o3W5YzEio216MTS5W10X'
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))