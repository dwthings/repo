Kodi repository for Zomboided's plugins
=======================================

Add this repository to your Kodi install to download and update Zomboided plugins
